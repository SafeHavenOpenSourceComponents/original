Contributing to SimpleAmqpClient
===============================

Thanks for contributing to SimpleAmqpClient. I firmly believe that 
participation help make open source software great.  With that in mind there 
are a few things you can do to make this interaction a bit smoother.

Please use the following guidelines when creating an issue or submitting
a pull request

Creating an issue
-----------------

Submitting a pull-request
------------------------
